CREATE TABLE IF NOT EXISTS clean_store_transactions(
    STORE_ID varchar(50),
    STORE_LOCATION varchar(50),
    PRODUCT_CATEGORY varchar(50),
    PRODUCT_ID INT,
    MRP float,
    CP float,
    DISCOUNT float,
    SP float,
    DATE date
);